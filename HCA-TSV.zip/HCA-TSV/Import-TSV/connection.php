<?php
function getdb(){
$servername = "127.0.0.1";
$username = "root";
$password = "root";
$db = "hca";

try {
   
    $conn = mysqli_connect($servername, $username, $password, $db);
     //echo "Connected successfully"; 
    }
catch(exception $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
    return $conn;
}
?>

