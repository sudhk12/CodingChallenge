<?php
include('connection.php');
$con = getdb();


   if(isset($_POST["Import"])){		
		echo $filename=$_FILES["file"]["tmp_name"];	
   // Exploding fields seperated by tabs and storing in an array

		 if($_FILES["file"]["size"] > 0)
		 {
			 $handle = fopen($filename, "r");
	       while (($getData = fgets($handle)) !== false) {

                $lineArr = explode("\t", "$getData");
                //var_dump($lineArr); // to make sure array is ok

                // Using php list -> http://php.net/manual/en/function.list.php            
                list($Item,$Item_description,$Item_price,$item_count,$Vendor,$Vendor_address) = $lineArr;
			 		
					//Inserting the data into Product table
		  	
	           $sql = "INSERT into product (Item,Item_description,Item_price,item_count,Vendor,Vendor_address) values ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$getData[5]."')";
	           $result = mysqli_query($con, $sql);
			    // var_dump(mysqli_error_list($con));
			    // exit();
				if(!isset($result))
				{
					echo "<script type=\"text/javascript\">
							alert(\"Invalid File:Please Upload TSV File.\");
							window.location = \"index.php\"
						  </script>";		
				}
				else {
					  echo "<script type=\"text/javascript\">
						alert(\"TSV File has been successfully Imported.\");
						window.location = \"index.php\"
					</script>";
				}
	         }
			
	         fclose($file);	
		 }
	}	 
	

	
function get_all_records(){
    $con = getdb();
      //select query with revenue calculation
    $Sql = "SELECT Item , Item_description ,Item_price,item_count,Vendor,Vendor_address, (Item_price * item_count) as Revenue FROM product";
    $result = mysqli_query($con, $Sql);  

    if (mysqli_num_rows($result) > 0) {
     echo "<div class='table-responsive'><table id='myTable' class='table table-striped table-bordered'>
     <thead>
     <tr>
     					<th>Item</th>
				  		<th>Item_description</th>
				  		<th>Item_price</th>
				  		<th>item_count</th>
				  		<th>Vendor</th>
						<th>Vendor_address</th>	
                        <th>Revenue</th>						
                        </tr></thead><tbody>";

     while($row = mysqli_fetch_assoc($result)) {


         echo "<tr><td>" . $row['Item']."</td>
                   <td>" . $row['Item_description']."</td>
                   <td>" . $row['Item_price']."</td>
                   <td>" . $row['item_count']."</td>
				   <td>" . $row['Vendor']."</td>				   
                   <td>" . $row['Vendor_address']."</td>
				   <td>" . $row['Revenue']."</td></tr>";
         
     }
	//  echo "<tr> <td><a href='' class='btn btn-danger' id='status_btn' data-loading-text='Changing Status..'>Export</a></td></tr>";
     echo "</tbody></table></div>";
	 
} else {
     echo "none";
}
$Sql2 = "select sum(item_price*item_count) as Total FROM product";
		$result2 = mysqli_query($con, $Sql2);
		
    
    if (mysqli_num_rows($result2) > 0) {
     echo "<div class='table-responsive'><table id='myTable' class='table table-striped table-bordered'>
     <thead>
     <tr>
     					<th>Total</th>				  				
                        </tr></thead><tbody>";

     while($row = mysqli_fetch_assoc($result2)) {


         echo "<td>" . $row['Total']."</td></tr>";
         
     }
	//  echo "<tr> <td><a href='' class='btn btn-danger' id='status_btn' data-loading-text='Changing Status..'>Export</a></td></tr>";
     echo "</tbody></table></div>";
	 
} else {
     echo "done";
	 
}

}



?>